
public abstract class Cell{
	public abstract String eval(Sheet sheet);
	public static void set() {
	}
	public String toString(Sheet sheet) {
		// TODO Auto-generated method stub
		return this.toString();
	}
}
