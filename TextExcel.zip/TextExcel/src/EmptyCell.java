
public class EmptyCell extends Cell{
	public EmptyCell(){
	}
	public String eval(Sheet sheet){
		String s = "";
		return s;
	}
	public String toString(){
		return "";
	}}